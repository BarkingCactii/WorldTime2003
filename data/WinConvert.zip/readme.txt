IMPORTANT!!
-----------

This is an older version of WinConvert98.

The latest version has an animated 3D menu plus more units.

The latest information and screen shots can be obtained from
http://www.home.aone.net.au/pcm
