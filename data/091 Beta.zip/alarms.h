#ifndef _ALARMS_H
#define _ALARMS_H

bool ProcessChimes ( CTime & localTime );
bool ProcessAlarms ( CTime & localTime );

#endif