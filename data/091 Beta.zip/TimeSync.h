#ifndef _TIMESYNC_H
#define _TIMESYNC_H

void TimeSync ( void );
void SkinList ( void );

#endif

