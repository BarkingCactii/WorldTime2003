#ifndef _SOUNDS_H
#define _SOUNDS_H

int Playsound ( const char *, bool );
int PlayAlarm ( char *, bool );

#endif